
public class MinhaExcecao extends Exception{ //checked
	
	public MinhaExcecao(String msg) {
		super(msg);
	}

}
